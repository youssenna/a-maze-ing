class ConfigsError(Exception):
    pass


class InvalidDistinationFor42Path(Exception):
    pass


class InvalidCoordinates(Exception):
    pass


class InvalidEntryExitPoint(Exception):
    pass
